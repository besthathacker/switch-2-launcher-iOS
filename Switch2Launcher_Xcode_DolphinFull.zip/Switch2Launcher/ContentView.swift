import SwiftUI

struct AppIcon: Identifiable {
    let id = UUID()
    let name: String
    let systemImage: String
}

struct ContentView: View {
    @State private var selectedIndex: Int = 0
    @State private var openApp: AppIcon? = nil
    @State private var bgColor: Color = .blue

    let apps = [
        AppIcon(name: "Phone", systemImage: "phone.fill"),
        AppIcon(name: "Messages", systemImage: "message.fill"),
        AppIcon(name: "Safari", systemImage: "safari.fill"),
        AppIcon(name: "Music", systemImage: "music.note"),
        AppIcon(name: "Photos", systemImage: "photo.fill"),
        AppIcon(name: "Dolphin", systemImage: "gamecontroller.fill"),
        AppIcon(name: "Settings", systemImage: "gearshape.fill")
    ]

    var body: some View {
        ZStack {
            LinearGradient(gradient: Gradient(colors: [bgColor.opacity(0.8), bgColor]),
                           startPoint: .topLeading, endPoint: .bottomTrailing)
                .ignoresSafeArea()
                .animation(.easeInOut(duration: 0.8), value: bgColor)

            VStack {
                Text("Switch 2 Launcher")
                    .font(.largeTitle)
                    .foregroundColor(.white)
                    .padding(.top, 20)

                Spacer()

                if openApp == nil {
                    TabView(selection: $selectedIndex) {
                        ForEach(apps.indices, id: \.self) { index in
                            VStack {
                                ZStack {
                                    RoundedRectangle(cornerRadius: 20)
                                        .fill(Color.white.opacity(0.2))
                                        .frame(width: 120, height: 120)
                                        .shadow(radius: 5)

                                    Image(systemName: apps[index].systemImage)
                                        .resizable()
                                        .scaledToFit()
                                        .frame(width: 50, height: 50)
                                        .foregroundColor(.white)
                                }
                                .onTapGesture {
                                    withAnimation {
                                        openApp = apps[index]
                                    }
                                }
                                Text(apps[index].name)
                                    .foregroundColor(.white)
                                    .font(.caption)
                            }
                            .padding()
                            .tag(index)
                        }
                    }
                    .tabViewStyle(PageTabViewStyle(indexDisplayMode: .never))
                    .frame(height: 200)
                } else {
                    VStack {
                        if openApp?.name == "Dolphin" {
                            DolphinView()
                                .frame(maxWidth: .infinity, maxHeight: .infinity)
                                .background(Color.black)
                        } else {
                            Text("\(openApp?.name ?? "") App")
                                .font(.title)
                                .foregroundColor(.white)
                        }

                        Button("Close") {
                            withAnimation {
                                openApp = nil
                            }
                        }
                        .padding()
                        .background(Color.white.opacity(0.2))
                        .cornerRadius(8)
                        .foregroundColor(.white)
                        .padding()
                    }
                }

                Spacer()
            }
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
