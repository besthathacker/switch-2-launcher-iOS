# Switch2Launcher (with Dolphin Placeholder)

This project includes:
- Full Switch 2 Launcher UI with a Dolphin emulator placeholder.
- A DolphinView that will load DolphinCore.framework if present.
- Frameworks folder ready for you to drop in DolphinCore.framework.
- GitHub Actions workflow for building and signing the IPA.

## Instructions
1. Add `DolphinCore.framework` into `Switch2Launcher/Frameworks/` if available.
2. Configure signing secrets in GitHub (P12_CERT, P12_PASSWORD, PROVISIONING_PROFILE).
3. Run the GitHub Actions workflow to build and download the IPA.
